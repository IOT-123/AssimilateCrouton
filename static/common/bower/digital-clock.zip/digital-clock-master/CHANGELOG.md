__v2.0.0__

  - update to polymer 2.x

__v1.0.2__

  - Fix box-sizing

__v1.0.1__

  - Fix alarm iron
  - Fix doc about custom style

__v1.0.0__

  - First release
